import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Read2014302580267 implements Runnable{
	private Buffer2014302580267 buffer;
	
	public Read2014302580267(Buffer2014302580267 buffer){
		this.buffer=buffer;
	}
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		
		Document doc;
		try {
			doc = Jsoup.connect("http://sc.xidian.edu.cn/html/teacher/daoshixinxi/").get();
			Elements trs=doc.getElementsByClass("middle_left_box1").get(0).getElementsByTag("tr");
			Element t=trs.get(2).getElementsByTag("td").get(1);
			Elements ele=t.getElementsByTag("a");
			
			for(int i=0;i<24;i++){
				if(i!=14){
				String link=ele.get(i).attr("href");
				Document d=Jsoup.connect(link).get();
				
				String name=ele.get(i).text();
				buffer.addLink(d,name);
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
		}
	
	public void singleThread() throws IOException{
		String url="jdbc:mysql://localhost:3306/Teacher?useUnicode=true&characterEncoding=utf-8";
		String user="root";
		String password="19950707";
		Statement st = null;
		
		Document doc = Jsoup.connect("http://sc.xidian.edu.cn/html/teacher/daoshixinxi/").get();
		Elements trs=doc.getElementsByClass("middle_left_box1").get(0).getElementsByTag("tr");
		Element t=trs.get(2).getElementsByTag("td").get(1);
		Elements ele=t.getElementsByTag("a");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("Fail to conect to the database!");
			e.printStackTrace();
		}
		
		for(int i=0;i<24;i++){
			
			if(i==14)continue;
			String link=ele.get(i).attr("href");
			Document d=Jsoup.connect(link).get();
			String name=ele.get(i).text();
			
			String brief="";
			Elements briefs=d.getElementById("n2").getElementsByTag("p");
			int n1=briefs.size();
			for(int j=0;j<n1;j++)
				brief=brief+briefs.get(j).text();
			
			String field=d.getElementById("n1").getElementsByTag("p").get(0).text();
			
			String contact="";
			Elements contacts=d.getElementById("n3").getElementsByTag("p");
			int n2=contacts.size();
			for(int j=0;j<n2;j++)
				contact=contact+contacts.get(j).text();
			
			
			String sql="insert into TeacherList(name,brief,field,contact) values('"+name+"','"+brief+"','"+field+"','"+contact+"');";
			
			try {
				st.executeUpdate(sql);
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
	}
	
	}
}


