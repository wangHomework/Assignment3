import java.io.IOException;


public class Main2014302580267 {
	public static void main(String[]args) throws InterruptedException, IOException{
		
		Buffer2014302580267 buffer=new Buffer2014302580267();
		Read2014302580267 read=new Read2014302580267(buffer);
		Parse2014302580267 parse=new Parse2014302580267(buffer);
		
		Thread t1=new Thread(read);
		Thread t2=new Thread(parse);
	
		long startTime = System.currentTimeMillis();
		
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		
		
		System.out.println("���߳�ʱ��: " + (System.currentTimeMillis() - startTime));

		long startTime2 = System.currentTimeMillis();
		
		
		
		SingleThread2014302580267 single=new SingleThread2014302580267();
		Thread t3=new Thread(single);
		t3.start();
		t3.join();
		System.out.println("���߳�ʱ��: " + (System.currentTimeMillis() - startTime2));
		}
	}

