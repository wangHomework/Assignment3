

public class Assignment3_2014302580105 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		singleThread();
		multiplyThread();
	}

	public static void multiplyThread() {
		TeacherArray2014302580105 teacherArray = new TeacherArray2014302580105();

		Thread thread1 = new Thread(new Input2014302580105(teacherArray));
		Thread thread2 = new Thread(new Output2014302580105(teacherArray));
		thread1.start();
		thread2.start();

	}

	public static void singleThread() {
		long singlestart = System.currentTimeMillis();
		TeacherArray2014302580105 teacherArray = new TeacherArray2014302580105();
		try {
			teacherArray.singleSetTeacher();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			teacherArray.singleGetTeacher();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long singleend = System.currentTimeMillis();
		System.out.println("���̺߳�ʱ��" + (singleend - singlestart) + "���롣");

	}
}
