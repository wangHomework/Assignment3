class Teacher2014302580105 {
	private String phone;
	private String title;
	private String direction;
	private String email;
	private String name;

	public Teacher2014302580105(String[] teacherInfo) {
		name = teacherInfo[0];
		title = teacherInfo[1];
		direction = teacherInfo[2];
		phone = teacherInfo[3];
		email = teacherInfo[4];
	}

	public String getPhone() {
		return phone;
	}

	public String getTitle() {
		return title;
	}

	public String getDirection() {
		return direction;
	}

	public String getEmail() {
		return email;
	}

	public String getName() {
		return name;
	}

}
