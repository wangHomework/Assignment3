import java.sql.DriverManager;
import java.sql.Statement;

import com.mysql.jdbc.Connection;

class Database2014302580105 {
	private String url = "jdbc:mysql://localhost:3306/TeacherInfo?";

	public Connection getConnection() throws Exception {
		Connection conn = null;
		Class.forName("com.mysql.jdbc.Driver");
		conn = (Connection) DriverManager.getConnection(url, "root", "123456");
		return conn;
	}

	public void runUpdate(Teacher2014302580105 teacher) throws Exception {
		Connection con = null;
		Statement sta = null;
		con = getConnection();
		sta = con.createStatement();
		String sql = "insert into teacher(name,title,direction,phone,email) " + "values('" + teacher.getName() + "','"
				+ teacher.getTitle() + "','" + teacher.getDirection() + "','" + teacher.getPhone() + "','"
				+ teacher.getEmail() + "')";
		sta.executeUpdate(sql);
		con.close();
		sta.close();
	}

}
