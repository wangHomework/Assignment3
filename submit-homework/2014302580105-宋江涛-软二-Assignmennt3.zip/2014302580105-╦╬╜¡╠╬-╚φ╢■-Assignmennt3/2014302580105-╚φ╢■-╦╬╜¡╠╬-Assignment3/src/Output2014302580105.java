class Output2014302580105 implements Runnable {
	private TeacherArray2014302580105 teacherArray;
	private Database2014302580105 database;

	public Output2014302580105(TeacherArray2014302580105 teacherArray) {
		this.teacherArray = teacherArray;
		database = new Database2014302580105();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		long multistart = System.currentTimeMillis();
		int i = 0;
		final int T = 100;
		while (i < T ) {
			try {
				database.runUpdate(teacherArray.getTeacher());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		long multiend = System.currentTimeMillis();
		System.out.println("���̺߳�ʱ:" + (multiend - multistart) + "����");

	}

}
