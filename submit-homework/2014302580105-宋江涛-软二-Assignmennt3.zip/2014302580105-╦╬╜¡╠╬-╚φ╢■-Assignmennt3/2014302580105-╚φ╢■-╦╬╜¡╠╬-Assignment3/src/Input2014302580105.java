class Input2014302580105 implements Runnable {
	private TeacherArray2014302580105 teacherArray;

	public Input2014302580105(TeacherArray2014302580105 teacherArray) {
		this.teacherArray = teacherArray;
	}

	public void run() {
		int i = 0;
		final int T = 100;
		while (i < T) {
			try {
				teacherArray.setTeacher(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
