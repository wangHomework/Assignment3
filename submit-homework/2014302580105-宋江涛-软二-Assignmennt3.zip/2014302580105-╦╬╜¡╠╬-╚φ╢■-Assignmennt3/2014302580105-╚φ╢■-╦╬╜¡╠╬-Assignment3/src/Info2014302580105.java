import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

class Info2014302580105 {
	private String[] urls;
	private String url = "http://staff.whu.edu.cn";


	public Info2014302580105() {
		try {
			urls = getURL(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String[] getURL(String url) throws IOException {
		String[] teachers = new String[100];
		Document doc = Jsoup.connect(url).get();
		Elements elements = doc.select("div.details > p > a[href]");
		int i = 0;
		for (Node node : elements) {
			teachers[i = i + 1] = node.attr("href");
		}
		return teachers;
	}

	public Teacher2014302580105 getTeacher(int index) throws IOException {
		String url = this.url + "/" + urls[index];
		Document doc = Jsoup.connect(url).get();
		int j = 0;
		Elements BI = doc.select("div.col-xs-7");
		String string1 = ">(.+)<";
		String[] teacherInfo = new String[5];
		Pattern p = Pattern.compile(string1);
		for (Element el : BI) {
			Matcher m = p.matcher(el.toString());
			while (m.find()) {
				String strs[] = m.group().replaceAll(string1, "$1").split("<br>");
				for (String str : strs) {

					String string2 = "(.*)(�о�����[^<]+)<.*";
					if (str.matches(string2)) {
						str = str.replaceAll(string2, "$1");
					}
					str = str.trim();
					teacherInfo[j = j + 1] = str;
				}
			}
		}
		return new Teacher2014302580105(teacherInfo);
	}
}