import java.io.IOException;

class TeacherArray2014302580105 {
	private int L = 0;
	private Teacher2014302580105[] teachers = new Teacher2014302580105[10];
	private Info2014302580105 teacherInfo = new Info2014302580105();
	private Teacher2014302580105[] singleTeachers = new Teacher2014302580105[100];
	private Database2014302580105 database = new Database2014302580105();
	private boolean signal = false;
	public synchronized void setTeacher(int index) throws IOException {
		while (signal) {
			try {
				wait();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		int i=L-1;
		for ( i = L - 1; i > 0; i--) {
			teachers[i] = teachers[i + 1];
		}
		teachers[0] = teacherInfo.getTeacher(index);
		L = L + 1;
		signal = true;
		notifyAll();

	}

	public synchronized Teacher2014302580105 getTeacher() {
		while (!signal) {
			try {
				wait();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Teacher2014302580105 temp = teachers[L - 1];
		L = L - 1;
		signal = false;
		notifyAll();
		return temp;
	}

	public void singleSetTeacher() throws Exception {
		int i = 0;
		final int T = 100;
		while( i < T) {
			singleTeachers[i] = teacherInfo.getTeacher(i);
		}
	}

	public void singleGetTeacher() throws Exception {
		int i = 0;
		final int T = 100;
		while( i < T) {
			database.runUpdate(singleTeachers[i]);
		}

	}
}
