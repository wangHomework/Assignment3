import java.io.File;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Buffer2014302580073
{
	private Lock lock;
	//private File[] file;
	//private int bufferNum;
	private String message[];
	
	public Buffer2014302580073()
	{
		/*bufferNum=20;
		file=new File[bufferNum];*/
		message=new String[4];
		lock=new ReentrantLock();
	}
	
	
	public void setMessage(String name,String tel,String mail,String introduce) throws InterruptedException
	{
		lock.lock();
		try
		{
			message[0]=name;
			message[1]=tel;
			message[2]=mail;
			message[3]=introduce;
			
		}finally
		{
			lock.unlock();
			//condition.signalAll();
		}
		
	}
	
	public String[] getMessage() throws InterruptedException
	{
		return message;
	}
}